import sys

# Adjust path so we can see the src modules running from branch as well
# as test dir:
sys.path.insert(0, '../../')
sys.path.insert(0, '../')
sys.path.insert(0, './')
